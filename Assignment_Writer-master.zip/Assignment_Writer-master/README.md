# Assignment_Writer
find it at :https://saiteja69.github.io/Assignment_Writer/<br />
A Vague attempt to convert a great tool to website , couldn't do this without @imlolman help! and swapnil sir's blessings<br />
V1.0 :<br />
 What works? <br />
  Small Letters (only)<br />
V2.0 :<br />
Capital Letters and numbers!
V3.0 : <br />
Everything works! , new handwriting styles added!
<br />
Output:
![alt text](https://github.com/SaiTeja69/Assignment_Writer/blob/master/output.jpg)

